FILES EDITED: 
	GL_Context.js
	animation.js
	shape.js
	index.html

Heirarchal
	The dog is drawn hierarchally: head->body->arms/legs

Polygonal/Flat Shading
	The entire dog is drawn polygonally. Each triangle that makes up the dog has vertices that contain multiple normals (in order to shade two adjacent triangles differently). The entire dog is shaded using flat shading.

Smooth Shading
	Only the dog's poo is flat shaded. You can tell by its gradient coloring.

Texture Mapped Objects
	The surrounding universe sphere, ground, transition scenes, and peach are all texture mapped using images provided.

Misc.
	The animation runs at a steady 60 FPS when the recording software is disabled. I could only meek out an average of 40-50 FPS while recording. It should run a lot smoother on your side.
	